<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\View;

use Illuminate\Http\Request;

class appController extends Controller
{
    //

    public function index()
    {
        return View::make('app.main');
    }
}
