<?php $__env->startSection('video'); ?>
    <div id="video" class="section">
      <div class="container">
        <div class="row">
          <div data-aos="fade-right" class="col-lg-6">
            <div class="title">
              <p class="bold f-header">Welcome to<br>Milenial Housing</p>
            </div>
            <div class="pb-40 f-content content">
              Hunian yang mengusung konsep Transit Oriented Development. Kami dari PT ESENSI PRIMA CIPTA menawarkan tempat tinggal yang Nyaman & Modern, dengan pilihan mode akses transportasi yang beragam. Anda juga dapat memiliki hunian dengan harga terjangkau didukung pilihan cara bayar yang fleksibel.
            </div>
          </div>
          <div data-aos="fade-left" class="col-lg-6">
            <iframe width="100%" height="315" src="https://www.youtube.com/embed/zCOSq3z4tiU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?><?php /**PATH C:\MAMP\htdocs\EPC\resources\views/component/video.blade.php ENDPATH**/ ?>