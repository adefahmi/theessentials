<?php $__env->startSection('spec'); ?>
    <div data-aos="fade-up" id="spec" class="section" data-bg="grey">
      <div class="container">
        <div class="pb-40 title">
          <p class="text-center f-header">Spesifikasi</p>
        </div>
        <div class="content">
          

          <div class="row">
            <div class="col-6 col-lg-4">
              <div class="text-center spec-icon">
                <img class="img-spec" src="<?php echo e(asset('libs/icon/lantai.svg')); ?>"/>
              </div>
              <div class="spec-name text-center">
                <h4 class="bold">Lantai</h4>
                <span><span class="bold b-color">*</span>Keramik</span>
              </div>
            </div>
            <div class="col-6 col-lg-4">
              <div class="text-center spec-icon">
                <img class="img-spec" src="<?php echo e(asset('libs/icon/pintu.svg')); ?>"/>
              </div>
              <div class="spec-name text-center">
                <h4 class="bold">Pintu</h4>
                <span><span class="bold b-color">*</span>Kayu/Kayu Lapis<br></span>
                <span><span class="bold b-color">*</span>Aluminium</span>
              </div>
            </div>

            <div class="col-6 col-lg-4 pb-40 ">
              <div class="text-center spec-icon">
                <img class="img-spec" src="<?php echo e(asset('libs/icon/icon_kamar_mandi.svg')); ?>"/>
              </div>
              <div class="spec-name text-center">
                <h4 class="bold">Kamar Mandi</h4>
                <span><span class="bold b-color">*</span>Keramik</span>
              </div>
            </div>

            

            <div class="col-6 col-lg-4">
              <div class="text-center spec-icon">
                <img class="img-spec" src="<?php echo e(asset('libs/icon/dinding.svg')); ?>"/>
              </div>
              <div class="spec-name text-center">
                <h4 class="bold">Dinding</h4>
                <span><span class="bold b-color">*</span>Dinding Bata / Hebel<br></span>
                <span><span class="bold b-color">*</span>Cat</span>
              </div>
            </div>

            <div class="col-6 col-lg-4">
              <div class="text-center spec-icon">
                <img class="img-spec" src="<?php echo e(asset('libs/icon/jendela.svg')); ?>"/>
              </div>
              <div class="spec-name text-center">
                <h4 class="bold">Jendela</h4>
                <span><span class="bold b-color">*</span>Kayu dan Kayu Lapis</span>
              </div>
            </div>

            <div class="col-6 col-lg-4">
              <div class="text-center spec-icon">
                <img class="img-spec" src="<?php echo e(asset('libs/icon/listrik.svg')); ?>"/>
              </div>
              <div class="spec-name text-center">
                <h4 class="bold">Instalasi Listrik dan Air</h4>
                <span><span class="bold b-color">*</span>PLN 900 Watt<br></span>
                <span><span class="bold b-color">*</span>Instalasi Air Komunal</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?><?php /**PATH C:\MAMP\htdocs\EPC\resources\views/component/spec.blade.php ENDPATH**/ ?>