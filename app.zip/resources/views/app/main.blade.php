@extends('layout.template')

@extends('component.menu')

@extends('component.carousel')

@extends('component.feature')

@extends('component.video')

@extends('component.type')

@extends('component.spec')

@extends('component.gallery')

@extends('component.akses')

@extends('component.denah')

@extends('component.tentang')

@extends('component.kontak')

{{-- @extends('component.footer2') --}}



