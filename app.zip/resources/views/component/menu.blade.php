@section("menu")
  <nav class="navbar navbar-expand-sm fixed-top navbar-light bg-light">
    <div class="container">
    <a class="navbar-brand" href="#"><img class='' height="50" src="{{asset('libs/image/logo_daru.png')}}" alt=""/></a>
        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
            aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavId">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a data-div='home' class="menu-link nav-link" href="#/">Home</a>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Fitur</a>
              <div class="dropdown-menu" aria-labelledby="dropdownId">
                <a data-div='feature' class="menu-link dropdown-item" href="#/">Fitur</a>
                <a data-div="type" class="menu-link dropdown-item" href="#/">Tipe</a>
                <a data-div="spec" class="menu-link dropdown-item" href="#/">Spesifikasi</a>
                <a data-div="gallery" class="menu-link dropdown-item" href="#/">Galeri</a>
                <a data-div="video" class="menu-link dropdown-item" href="#/">Vidio</a>
              </div>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Akses</a>
              <div class="dropdown-menu" aria-labelledby="dropdownId">
                <a data-div="denah" class="menu-link dropdown-item" href="#/">Lokasi</a>
                <a data-div="akses" class="menu-link dropdown-item" href="#/">Akses</a>
              </div>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Hubungi Kami</a>
              <div class="dropdown-menu" aria-labelledby="dropdownId">
                <a data-div="tentang" class="menu-link dropdown-item" href="#/">Tentang Kami</a>
                <a data-div="kontak" class="menu-link dropdown-item" href="#/">Hubungi Kami</a>
              </div>
            </li>
            
          </ul>
        </div>
    </div>
  </nav>
  
@stop