@section('gallery')
    <div id="gallery" class="section">
      <div class="">
        <div data-aos="zoom-in" class="pb-40 title">
          <p class="text-center f-header">Gallery</p>
        </div>
        <div data-aos="fade-up" class="content">

          <div class="wrapper">

            <div class="jcarousel-wrapper">
                <div class="jcarousel">
                    <ul>
                        <li><img src="{{asset('libs/carousel/gallery/1.jpg')}}" width="600" height="400" alt=""></li>
                        <li><img src="{{asset('libs/carousel/gallery/2.jpg')}}" width="600" height="400" alt=""></li>
                        <li><img src="{{asset('libs/carousel/gallery/3.jpg')}}" width="600" height="400" alt=""></li>
                        <li><img src="{{asset('libs/carousel/gallery/4.jpg')}}" width="600" height="400" alt=""></li>
                    </ul>
                </div>

                <a href="#" class="control-carousel jcarousel-control-prev">&lsaquo;</a>
                <a href="#" class="control-carousel jcarousel-control-next">&rsaquo;</a>
                
                <p class="jcarousel-pagination">
                    
                </p>
            </div>
        </div>
          
          

        </div>
      </div>
    </div>
@endsection