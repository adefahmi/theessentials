@section('tentang')
    <div data-aos="zoom-in" id="tentang" class="section">
      <div class="container">
        <div class="pb-40 title">
          <p class="f-header text-center">Tentang Developer</p>
          <p class="f-header bold text-center">PT Esesnsi Prima Cipta</p>
        </div>
        <div class="content">
          <div class="row">
            <div class="mb-20x col-12 col-md-6 offset-md-3">
              <div id="carouselIdTentang" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner" role="listbox">
                  <div class="carousel-item type active" style="background-image: url({{asset('libs/carousel/slide1.jpeg')}})">
                    
                  </div>
                  {{-- <div class="carousel-item type" style="background-image: url({{asset('libs/carousel/slide2.jpeg')}})">
                   
                  </div> --}}
                </div>
               
              </div>
            </div>
            {{-- <div class="col-lg-6">
              <div class="pb-40 title">
                
              </div>
              <div class="content">
               
              </div>
            </div> --}}
          </div>
        </div>
      </div>
    </div>
@endsection